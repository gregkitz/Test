package com.persist.uw.examples

/**
  * Created by gkitzmil on 10/31/16.
  */
object Main extends App {
  val s1 = FSet().add(1).add(2)


}
